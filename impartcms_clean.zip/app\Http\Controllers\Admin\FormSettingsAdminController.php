<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class FormSettingsAdminController extends Controller
{
    public function edit(): View
    {
        return view('admin.forms.settings', [
            'defaults' => [
                'default_to' => (string) Setting::get('forms_default_to', ''),
                'from_name' => (string) Setting::get('forms_from_name', ''),
                'from_email' => (string) Setting::get('forms_from_email', ''),
                'reply_to' => (string) Setting::get('forms_reply_to', ''),
            ],
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'default_to' => ['nullable', 'string', 'max:255'],
            'from_name' => ['nullable', 'string', 'max:255'],
            'from_email' => ['nullable', 'string', 'max:255'],
            'reply_to' => ['nullable', 'string', 'max:255'],
        ]);

        // We store raw strings; validation for CSV emails is handled on send.
        Setting::set('forms_default_to', trim((string)($data['default_to'] ?? '')));
        Setting::set('forms_from_name', trim((string)($data['from_name'] ?? '')));
        Setting::set('forms_from_email', trim((string)($data['from_email'] ?? '')));
        Setting::set('forms_reply_to', trim((string)($data['reply_to'] ?? '')));

        return back()->with('status', 'Forms settings saved ✅');
    }
}
