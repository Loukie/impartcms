// ImpartCMS — Generate a light Font Awesome icon list for the admin icon picker
//
// Why this exists:
// - We only need name + styles for the icon grid.
// - Keeps the admin icon picker fast and the bundle lean.
//
// Output:
//   resources/js/admin/fa-icons.json
// Shape (array):
//   { name: string, label: string, styles: string[] }

import fs from 'node:fs';
import path from 'node:path';

const projectRoot = process.cwd();

// Resolve @fortawesome metadata path reliably on Windows + POSIX
const metadataPath = path.join(
  projectRoot,
  'node_modules',
  '@fortawesome',
  'fontawesome-free',
  'metadata',
  'icons.json'
);

const outPath = path.join(projectRoot, 'resources', 'js', 'admin', 'fa-icons.json');

if (!fs.existsSync(metadataPath)) {
  console.warn('[fa:icons] Font Awesome metadata not found (icons.json). Skipping generation and keeping existing resources/js/admin/fa-icons.json');
  process.exit(0);
}

const raw = fs.readFileSync(metadataPath, 'utf8');
const icons = JSON.parse(raw);

// icons is an object keyed by icon name
const list = Object.entries(icons).map(([name, meta]) => {
  const styles = Array.isArray(meta?.styles) ? meta.styles.map(s => String(s)) : [];
  const label = String(meta?.label || name);
  return { name, label, styles };
});

// Sort by label for nicer UX
list.sort((a, b) => a.label.localeCompare(b.label));

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(list, null, 2) + '\n', 'utf8');

console.log(`[fa:icons] Generated ${list.length} icons → ${outPath}`);
