import ICONS from "./fa-icons.json";
export default ICONS;
export const FA_ICON_LIST = ICONS;
