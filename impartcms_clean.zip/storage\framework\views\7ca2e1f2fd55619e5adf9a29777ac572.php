<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">Forms</h2>

            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('admin.forms.settings.edit')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-900 uppercase tracking-widest hover:bg-gray-50">
                    Settings
                </a>

                <a href="<?php echo e(route('admin.forms.create')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-gray-900 text-white rounded-md font-semibold text-xs uppercase tracking-widest hover:bg-gray-800">
                    New Form
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('status')): ?>
                <div class="mb-4 p-3 rounded bg-green-50 text-green-800 border border-green-200">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <form method="GET" class="flex items-end gap-3 mb-6">
                        <div class="flex-1">
                            <label class="block text-sm font-medium text-gray-700">Search</label>
                            <input type="text" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Search name or slug…"
                                   class="mt-1 w-full rounded-md border-gray-300">
                        </div>
                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-900 uppercase tracking-widest hover:bg-gray-50">
                            Apply
                        </button>
                    </form>

                    <div class="overflow-x-auto">
                        <table class="min-w-full text-sm">
                            <thead>
                                <tr class="text-left text-gray-500 border-b">
                                    <th class="py-2 pr-4">Name</th>
                                    <th class="py-2 pr-4">Slug</th>
                                    <th class="py-2 pr-4">Active</th>
                                    <th class="py-2 pr-4">Submissions</th>
                                    <th class="py-2 pr-4">Updated</th>
                                    <th class="py-2">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b last:border-0">
                                        <td class="py-3 pr-4 font-semibold text-gray-900">
                                            <a class="hover:underline" href="<?php echo e(route('admin.forms.edit', $form)); ?>"><?php echo e($form->name); ?></a>
                                        </td>
                                        <td class="py-3 pr-4 text-gray-700"><?php echo e($form->slug); ?></td>
                                        <td class="py-3 pr-4">
                                            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-semibold <?php echo e($form->is_active ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-gray-100 text-gray-700 border border-gray-200'); ?>">
                                                <?php echo e($form->is_active ? 'Yes' : 'No'); ?>

                                            </span>
                                        </td>
                                        <td class="py-3 pr-4 text-gray-700">
                                            <?php echo e($form->submissions()->count()); ?>

                                        </td>
                                        <td class="py-3 pr-4 text-gray-500"><?php echo e($form->updated_at?->format('Y-m-d H:i')); ?></td>
                                        <td class="py-3">
                                            <div class="flex items-center gap-2">
                                                <a href="<?php echo e(route('admin.forms.submissions.index', $form)); ?>"
                                                   class="inline-flex items-center px-3 py-1.5 rounded-md border bg-white text-xs font-semibold hover:bg-gray-50">
                                                    View submissions
                                                </a>
                                                <a href="<?php echo e(route('admin.forms.edit', $form)); ?>"
                                                   class="inline-flex items-center px-3 py-1.5 rounded-md bg-gray-900 text-white text-xs font-semibold hover:bg-gray-800">
                                                    Edit
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="py-6 text-gray-600">No forms yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6">
                        <?php echo e($forms->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\2kocms\resources\views/admin/forms/index.blade.php ENDPATH**/ ?>