<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@php
    /**
     * Admin branding
     * - If no logo: show site name text
     * - If logo: show logo-only by default
     * - Optional setting: allow logo + text
     * - Logo can be either an uploaded settings logo OR a Media library item
     */
    $siteName = \App\Models\Setting::get('site_name', config('app.name', 'ImpartCMS'));

    $logoPath = \App\Models\Setting::get('site_logo_path', null);
    $logoMediaId = (int) (\App\Models\Setting::get('site_logo_media_id', '0') ?? 0);
    $logoIconJson = \App\Models\Setting::get('site_logo_icon_json', null);
    $showNameWithLogo = (bool) ((int) \App\Models\Setting::get('admin_show_name_with_logo', '0'));

    $logoUrl = null;
    if ($logoMediaId > 0) {
        $m = \App\Models\MediaFile::query()->whereKey($logoMediaId)->first();
        if ($m && $m->isImage()) {
            $logoUrl = $m->url;
        }
    }

    if (!$logoUrl && !empty($logoPath)) {
        $logoUrl = asset('storage/' . $logoPath);
    }

    // Optional icon logo (fallback when no image)
    $logoIconHtml = '';
    if (empty($logoUrl) && !empty($logoIconJson)) {
        $j = $logoIconJson;
        try {
            $arr = json_decode((string) $logoIconJson, true, 512, JSON_THROW_ON_ERROR);
            if (is_array($arr)) {
                // If user kept default dark colour, make it visible on dark admin sidebar.
                if (($arr['colour'] ?? '') === '#111827') {
                    $arr['colour'] = '#ffffff';
                }
                $j = json_encode($arr, JSON_UNESCAPED_SLASHES);
            }
        } catch (\Throwable $e) {
            $j = $logoIconJson;
        }

        $logoIconHtml = \App\Support\IconRenderer::renderHtml($j, 28, '#ffffff');
    }

    $hasLogo = !empty($logoUrl) || !empty($logoIconHtml);
    $showText = !$hasLogo || $showNameWithLogo;

// Favicon (admin)
$faviconPath = \App\Models\Setting::get('site_favicon_path', null);
$faviconMediaId = (int) (\App\Models\Setting::get('site_favicon_media_id', '0') ?? 0);
$faviconIconJson = \App\Models\Setting::get('site_favicon_icon_json', null);
$faviconUrl = null;

if ($faviconMediaId > 0) {
    $f = \App\Models\MediaFile::query()->whereKey($faviconMediaId)->first();
    if ($f && ($f->isImage() || (is_string($f->mime_type ?? null) && str_starts_with($f->mime_type, 'image/')))) {
        $faviconUrl = $f->url;
    }
}

if (!$faviconUrl && !empty($faviconPath)) {
    $faviconUrl = asset('storage/' . $faviconPath);
}

$faviconIconUrl = null;
if (empty($faviconUrl) && !empty($faviconIconJson)) {
    $faviconIconUrl = route('favicon.svg');
}

    $isActive = fn(string $pattern) => request()->routeIs($pattern);
@endphp
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ $siteName }} Admin</title>

    @if(!empty($faviconUrl))
        <link rel="icon" href="{{ $faviconUrl }}">
    @elseif(!empty($faviconIconUrl))
        <link rel="icon" type="image/svg+xml" href="{{ $faviconIconUrl }}">
    @endif

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
    /* Admin-only: remove Breeze-style max container widths so admin pages feel fuller */
    .admin-shell .max-w-7xl,
    .admin-shell .max-w-6xl,
    .admin-shell .max-w-5xl,
    .admin-shell .max-w-4xl,
    .admin-shell .max-w-3xl,
    .admin-shell .max-w-2xl,
    .admin-shell .max-w-xl,
    .admin-shell .max-w-lg,
    .admin-shell .max-w-md,
    .admin-shell .max-w-sm,
    .admin-shell .max-w-xs,
    .admin-shell .container {
        max-width: none !important;
    }

    .admin-shell .mx-auto {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }
</style>
</head>
<body class="min-h-screen bg-slate-50 admin-shell">
<div class="min-h-screen flex">
    {{-- Sidebar --}}
    <aside class="w-64 bg-slate-950 text-white flex-shrink-0 border-r border-white/5">
        <div class="px-4 py-4 border-b border-white/10">
            <a href="{{ route('dashboard') }}" class="flex items-center gap-3 {{ $showText ? '' : 'justify-center' }}">
                @if(!empty($logoUrl))
                    <img src="{{ $logoUrl }}" alt="{{ $siteName }} logo" class="h-8 w-auto">
                @elseif(!empty($logoIconHtml))
                    <span class="inline-flex items-center justify-center h-8 w-8">{!! $logoIconHtml !!}</span>
                @endif

                @if($showText)
                    <div class="min-w-0">
                        <div class="text-base font-semibold tracking-tight truncate">{{ $siteName }}</div>
                        <div class="text-xs text-white/60 mt-0.5">Admin</div>
                    </div>
                @else
                    <span class="sr-only">{{ $siteName }} Admin</span>
                @endif
            </a>
        </div>

        @php
            $linkBase = 'group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition';
            $linkInactive = 'text-white/80 hover:text-white hover:bg-white/10';
            $linkActive = 'bg-white/10 text-white';
            $iconInactive = 'text-white/60 group-hover:text-white/80';
            $iconActive = 'text-white';
        @endphp

        <nav class="p-3 space-y-1">
            {{-- Dashboard --}}
            <a href="{{ route('dashboard') }}" class="{{ $linkBase }} {{ $isActive('dashboard') ? $linkActive : $linkInactive }}">
                <svg class="h-4 w-4 flex-none {{ $isActive('dashboard') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M11.47 2.22a1.5 1.5 0 0 1 1.06 0l7.5 2.75A1.5 1.5 0 0 1 21 6.38v6.82c0 3.6-2.26 6.9-5.64 8.26l-2.35.94a2 2 0 0 1-1.5 0l-2.35-.94C5.76 20.1 3.5 16.8 3.5 13.2V6.38A1.5 1.5 0 0 1 4.47 4.97l7-2.75Z"/>
                </svg>
                <span>Dashboard</span>
            </a>

            {{-- View site: MUST be in sidebar under Dashboard --}}
            <a href="{{ url('/') }}" target="_blank" rel="noopener" class="{{ $linkBase }} {{ $linkInactive }}">
                <svg class="h-4 w-4 flex-none {{ $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M13.5 4.5a1.5 1.5 0 0 0 0 3h1.88l-6.44 6.44a1.5 1.5 0 1 0 2.12 2.12l6.44-6.44V11.5a1.5 1.5 0 0 0 3 0V6a1.5 1.5 0 0 0-1.5-1.5h-5.5Z"/>
                    <path d="M6 6.75A2.25 2.25 0 0 0 3.75 9v9A2.25 2.25 0 0 0 6 20.25h9A2.25 2.25 0 0 0 17.25 18v-4.5a.75.75 0 0 0-1.5 0V18c0 .414-.336.75-.75.75H6A.75.75 0 0 1 5.25 18V9c0-.414.336-.75.75-.75h4.5a.75.75 0 0 0 0-1.5H6Z"/>
                </svg>
                <span>View site</span>
            </a>

            <div class="my-3 border-t border-white/10"></div>

            {{-- Pages --}}
            <a href="{{ route('admin.pages.index') }}" class="{{ $linkBase }} {{ $isActive('admin.pages.*') ? $linkActive : $linkInactive }}">
                <svg class="h-4 w-4 flex-none {{ $isActive('admin.pages.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M6 2.25A2.25 2.25 0 0 0 3.75 4.5v15A2.25 2.25 0 0 0 6 21.75h12A2.25 2.25 0 0 0 20.25 19.5v-10.5L14.25 2.25H6Zm7.5 1.56V9h5.19L13.5 3.81Z"/>
                    <path d="M7.5 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 7.5 12Zm0 3a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 7.5 15Z"/>
                </svg>
                <span>Pages</span>
            </a>

            {{-- AI Site Builder --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.site-builder.create'))
                <a href="{{ route('admin.site-builder.create') }}" class="{{ $linkBase }} {{ $isActive('admin.site-builder.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.site-builder.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M12 2.25a.75.75 0 0 1 .75.75v1.08a7.5 7.5 0 0 1 2.18.9l.77-.77a.75.75 0 0 1 1.06 0l1.06 1.06a.75.75 0 0 1 0 1.06l-.77.77c.39.68.68 1.42.85 2.2H19.5a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-.75.75h-1.08a7.5 7.5 0 0 1-.9 2.18l.77.77a.75.75 0 0 1 0 1.06l-1.06 1.06a.75.75 0 0 1-1.06 0l-.77-.77a7.5 7.5 0 0 1-2.2.85V21a.75.75 0 0 1-.75.75h-1.5A.75.75 0 0 1 10.5 21v-1.08a7.5 7.5 0 0 1-2.18-.9l-.77.77a.75.75 0 0 1-1.06 0L5.43 18.5a.75.75 0 0 1 0-1.06l.77-.77a7.5 7.5 0 0 1-.85-2.2H4.5a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 1 .75-.75h1.08a7.5 7.5 0 0 1 .9-2.18l-.77-.77a.75.75 0 0 1 0-1.06l1.06-1.06a.75.75 0 0 1 1.06 0l.77.77a7.5 7.5 0 0 1 2.2-.85V3a.75.75 0 0 1 .75-.75H12Zm0 6a3.75 3.75 0 1 0 0 7.5 3.75 3.75 0 0 0 0-7.5Z"/>
                    </svg>
                    <span>AI Site Builder</span>
                </a>
            @endif

            {{-- Media --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.media.index'))
                <a href="{{ route('admin.media.index') }}" class="{{ $linkBase }} {{ $isActive('admin.media.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.media.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M4.5 5.25A2.25 2.25 0 0 1 6.75 3h10.5A2.25 2.25 0 0 1 19.5 5.25v13.5A2.25 2.25 0 0 1 17.25 21H6.75A2.25 2.25 0 0 1 4.5 18.75V5.25Zm12 3a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0Zm-9.75 9.69 2.22-2.22 1.66 1.66 4.12-4.12a.75.75 0 0 1 1.06 0l2.19 2.19v3.84c0 .414-.336.75-.75.75H6.75a.75.75 0 0 1-.75-.75v-1.35Z"/>
                    </svg>
                    <span>Media</span>
                </a>
            @endif

            {{-- Forms --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.forms.index'))
                <a href="{{ route('admin.forms.index') }}" class="{{ $linkBase }} {{ $isActive('admin.forms.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.forms.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M6 2.25A2.25 2.25 0 0 0 3.75 4.5v15A2.25 2.25 0 0 0 6 21.75h12A2.25 2.25 0 0 0 20.25 19.5v-15A2.25 2.25 0 0 0 18 2.25H6Zm2.25 6a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z"/>
                    </svg>
                    <span>Forms</span>
                </a>
            @endif

            {{-- Users --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.users.index'))
                <a href="{{ route('admin.users.index') }}" class="{{ $linkBase }} {{ $isActive('admin.users.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.users.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M16.5 7.5a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0Z"/>
                        <path d="M3.75 20.25a7.5 7.5 0 0 1 15 0 .75.75 0 0 1-.75.75H4.5a.75.75 0 0 1-.75-.75Z"/>
                    </svg>
                    <span>Users</span>
                </a>
            @endif

            {{-- Settings --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.settings.edit'))
                <a href="{{ route('admin.settings.edit') }}" class="{{ $linkBase }} {{ $isActive('admin.settings.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.settings.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M11.983 1.5a1.5 1.5 0 0 1 1.484 1.28l.17 1.14a7.92 7.92 0 0 1 1.82.75l1.05-.5a1.5 1.5 0 0 1 1.86.53l1.5 2.6a1.5 1.5 0 0 1-.38 1.95l-.93.72c.08.6.08 1.22 0 1.82l.93.72a1.5 1.5 0 0 1 .38 1.95l-1.5 2.6a1.5 1.5 0 0 1-1.86.53l-1.05-.5a7.92 7.92 0 0 1-1.82.75l-.17 1.14A1.5 1.5 0 0 1 11.983 22.5h-3a1.5 1.5 0 0 1-1.484-1.28l-.17-1.14a7.92 7.92 0 0 1-1.82-.75l-1.05.5a1.5 1.5 0 0 1-1.86-.53l-1.5-2.6a1.5 1.5 0 0 1 .38-1.95l.93-.72a7.7 7.7 0 0 1 0-1.82l-.93-.72a1.5 1.5 0 0 1-.38-1.95l1.5-2.6a1.5 1.5 0 0 1 1.86-.53l1.05.5c.58-.3 1.18-.56 1.82-.75l.17-1.14A1.5 1.5 0 0 1 8.983 1.5h3Zm-1.5 7.5a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"/>
                    </svg>
                    <span>Settings</span>
                </a>
            @endif

            {{-- AI Agent --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.ai-agent.edit'))
                <a href="{{ route('admin.ai-agent.edit') }}" class="{{ $linkBase }} {{ $isActive('admin.ai-agent.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.ai-agent.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M12 2.25a.75.75 0 0 1 .75.75v1.08a7.5 7.5 0 0 1 2.18.9l.77-.77a.75.75 0 0 1 1.06 0l1.06 1.06a.75.75 0 0 1 0 1.06l-.77.77c.39.68.68 1.42.85 2.2H19.5a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-.75.75h-1.08a7.5 7.5 0 0 1-.9 2.18l.77.77a.75.75 0 0 1 0 1.06l-1.06 1.06a.75.75 0 0 1-1.06 0l-.77-.77a7.5 7.5 0 0 1-2.2.85V21a.75.75 0 0 1-.75.75h-1.5A.75.75 0 0 1 10.5 21v-1.08a7.5 7.5 0 0 1-2.18-.9l-.77.77a.75.75 0 0 1-1.06 0L5.43 18.5a.75.75 0 0 1 0-1.06l.77-.77a7.5 7.5 0 0 1-.85-2.2H4.5a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 1 .75-.75h1.08a7.5 7.5 0 0 1 .9-2.18l-.77-.77a.75.75 0 0 1 0-1.06l1.06-1.06a.75.75 0 0 1 1.06 0l.77.77a7.5 7.5 0 0 1 2.2-.85V3a.75.75 0 0 1 .75-.75H12Zm0 6a3.75 3.75 0 1 0 0 7.5 3.75 3.75 0 0 0 0-7.5Z"/>
                    </svg>
                    <span>AI Agent</span>
                </a>
            @endif

            {{-- Header & Footer --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.layout-blocks.index'))
                <a href="{{ route('admin.layout-blocks.index') }}" class="{{ $linkBase }} {{ $isActive('admin.layout-blocks.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.layout-blocks.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M4.5 6.75A2.25 2.25 0 0 1 6.75 4.5h10.5A2.25 2.25 0 0 1 19.5 6.75v10.5A2.25 2.25 0 0 1 17.25 19.5H6.75A2.25 2.25 0 0 1 4.5 17.25V6.75Zm2.25-.75a.75.75 0 0 0-.75.75v.75h12v-.75a.75.75 0 0 0-.75-.75H6.75Zm11.25 12H6v.75c0 .414.336.75.75.75h10.5c.414 0 .75-.336.75-.75V18Zm-12 0h12V9H6v9Z"/>
                    </svg>
                    <span>Header &amp; Footer</span>
                </a>
            @endif

            {{-- Custom code (CSS + Scripts) --}}
            @if(\Illuminate\Support\Facades\Route::has('admin.snippets.index'))
                <a href="{{ route('admin.snippets.index') }}" class="{{ $linkBase }} {{ $isActive('admin.snippets.*') ? $linkActive : $linkInactive }}">
                    <svg class="h-4 w-4 flex-none {{ $isActive('admin.snippets.*') ? $iconActive : $iconInactive }}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M8.7 7.2a.75.75 0 0 1 0 1.06L5.96 11l2.74 2.74a.75.75 0 1 1-1.06 1.06L4.38 11.53a.75.75 0 0 1 0-1.06l3.26-3.27a.75.75 0 0 1 1.06 0Zm6.6 0a.75.75 0 0 1 1.06 0l3.26 3.27a.75.75 0 0 1 0 1.06l-3.26 3.27a.75.75 0 1 1-1.06-1.06L18.04 11l-2.74-2.74a.75.75 0 0 1 0-1.06Z"/>
                        <path d="M13.65 5.1a.75.75 0 0 1 .53.92l-2.5 13a.75.75 0 1 1-1.47-.28l2.5-13a.75.75 0 0 1 .94-.64Z"/>
                    </svg>
                    <span>Custom code</span>
                </a>
            @endif
        </nav>
    </aside>

    {{-- Main --}}
    <div class="flex-1 min-w-0">
        {{-- Top bar --}}
        <header class="bg-white/80 backdrop-blur border-b border-slate-200">
            <div class="px-6 py-4 flex items-center justify-between">
                <div class="text-sm text-slate-600">
                    Logged in as <span class="font-semibold text-slate-900">{{ Auth::user()->name }}</span>
                </div>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="text-sm font-semibold text-slate-700 hover:text-slate-900">
                        Log out
                    </button>
                </form>
            </div>

            @if (isset($header))
                <div class="px-6 pb-4">
                    {{ $header }}
                </div>
            @elseif (View::hasSection('header'))
                <div class="px-6 pb-4">
                    @yield('header')
                </div>
            @endif
        </header>

        <main class="px-6 py-6">
            @if (isset($slot))
                {{ $slot }}
            @else
                @yield('content')
            @endif
        </main>
    </div>
</div>

{{-- Global Media Picker Modal (WordPress-style) --}}
<div id="impart-media-modal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/60" data-impart-media-close></div>

    {{-- Centered modal container --}}
    <div class="relative min-h-screen w-full flex items-center justify-center p-4 sm:p-6">
        <div class="w-full max-w-[1440px] h-[92vh] bg-white rounded-xl shadow-2xl overflow-hidden flex flex-col">
        <div class="flex items-center justify-between px-4 py-3 border-b border-slate-200">
            <div class="text-sm font-semibold text-slate-900">Select media</div>
            <button type="button" class="text-sm font-semibold text-slate-700 hover:text-slate-900" data-impart-media-close>
                Cancel
            </button>
        </div>
        <iframe id="impart-media-iframe" class="flex-1 w-full" src="about:blank"></iframe>
        </div>
    </div>
</div>

<script>
(function () {
    const modal = document.getElementById('impart-media-modal');
    const iframe = document.getElementById('impart-media-iframe');

    let onSelect = null;

    function closeModal() {
        modal.classList.add('hidden');
        iframe.src = 'about:blank';
        onSelect = null;
        document.documentElement.style.overflow = '';
    }

    function openModal(opts) {
        const url = (opts && opts.url) ? opts.url : "{{ route('admin.media.picker') }}";
        onSelect = (opts && typeof opts.onSelect === 'function') ? opts.onSelect : null;

        iframe.src = url;
        modal.classList.remove('hidden');
        document.documentElement.style.overflow = 'hidden';
    }

    window.ImpartMediaPicker = {
        open: openModal,
        close: closeModal,
    };

    modal.addEventListener('click', (e) => {
        if (e.target && e.target.hasAttribute('data-impart-media-close')) closeModal();
    });

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeModal();
    });

    window.addEventListener('message', (event) => {
        try {
            if (event.origin !== window.location.origin) return;
            const data = event.data || {};
            if (data.type === 'impartcms-media-cancel' || data.type === 'impart-media-cancel') {
                closeModal();
                return;
            }
            if (data.type !== 'impartcms-media-selected' && data.type !== 'impart-media-selected') return;

            // Normalise payload shape (old patches may post payload directly)
            const payload = (data && typeof data === 'object' && 'payload' in data) ? data.payload : data;
            if (onSelect) onSelect(payload);
            closeModal();
        } catch (e) {
            // ignore
        }
    });
})();
</script>
</body>
</html>
