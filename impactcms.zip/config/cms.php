<?php

return [
    'admin_path' => env('CMS_ADMIN_PATH', 'admin'),
    'modules_path' => base_path('modules'),
    'theme' => env('CMS_THEME', 'default'),
];
